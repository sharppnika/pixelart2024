1.back_grass放置在tree的前面，platform的后面，紧贴右下角
2.back、back_grass、front_leaves都需要做循环拼接，其余自由摆放
3.循环拼接时，拼接偏移量为x方向-52px，y方向108px（原始像素大小）。此偏移量相对于平行拼接而言，可参考之前的拼接示意图。